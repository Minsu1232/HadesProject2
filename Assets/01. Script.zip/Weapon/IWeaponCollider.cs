public interface IWeaponCollider
{
    void ActivateCollider();
    void DeactivateCollider();
}