//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//public class ItemInit : MonoBehaviour
//{
//    // Start is called before the first frame update
//    async void Awake()
//    {
       

//    }

//    // Update is called once per frame
//    void Update()
//    {
        
//    }
//}
