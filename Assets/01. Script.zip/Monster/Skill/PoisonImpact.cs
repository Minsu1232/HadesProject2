//using UnityEngine;

//public class PoisonImpact : IProjectileImpact
//{
//    //private GameObject poisonAreaPrefab;

//    //public PoisonImpact(GameObject poisonAreaPrefab)
//    //{
//    //    this.poisonAreaPrefab = poisonAreaPrefab;
//    //}

//    //public void OnImpact(Vector3 impactPosition, float damage)
//    //{
//    //    if (poisonAreaPrefab == null) return;

//    //    GameObject poisonArea = Object.Instantiate(poisonAreaPrefab, impactPosition, Quaternion.identity);
//    //    if (poisonArea.TryGetComponent<PoisonArea>(out var poison))
//    //    {
//    //        poison.Initialize(damage);
//    //    }
//    //}
//}