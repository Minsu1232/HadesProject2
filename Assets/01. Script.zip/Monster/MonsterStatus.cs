using Sirenix.OdinInspector;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Unity.VisualScripting;
using UnityEngine;
using static AttackData;
using static IMonsterState;

public class MonsterStatus : MonoBehaviour, IDamageable, ICreatureStatus
{
    [SerializeField] CreatureAI creatureAI;
    [SerializeField] private Transform skillSpawnPoint;
    private MonsterUIManager uiManager;
    protected SimpleDissolveController simpleDissolveContorller;
    protected bool isDie = false;
    [FoldoutGroup("Monster Stats")]
    [ReadOnly]
    [ShowInInspector]    
    protected IMonsterClass monsterClass;  // MonsterClass ��� �������̽� ���
    [FoldoutGroup("Current Stats"), ReadOnly]
    [ShowInInspector]
    public int CurrentHealth => monsterClass?.CurrentHealth ?? 0;

    [FoldoutGroup("Current Stats"), ReadOnly]
    [ShowInInspector]
    public int CurrentDefense => monsterClass?.CurrentDeffense ?? 0;

    [FoldoutGroup("Current Stats"), ReadOnly]
    [ShowInInspector]
    public int CurrentAttackPower => monsterClass?.CurrentAttackPower ?? 0;

    [FoldoutGroup("Current Stats"), ReadOnly]
    [ShowInInspector]
    public float CurrentAttackSpeed => monsterClass?.CurrentAttackSpeed ?? 0;

    [FoldoutGroup("Current Stats"), ReadOnly]
    [ShowInInspector]
    public int CurrentSpeed => monsterClass?.CurrentSpeed ?? 0;

    [FoldoutGroup("Current Stats"), ReadOnly]
    [ShowInInspector]
    public float CurrentAttackRange => monsterClass?.CurrentAttackRange ?? 0;

    [FoldoutGroup("Skill Stats"), ReadOnly]
    [ShowInInspector]
    public float CurrentSkillCooldown => monsterClass?.CurrentSkillCooldown ?? 0;

    [FoldoutGroup("Skill Stats"), ReadOnly]
    [ShowInInspector]
    public float CurrentSkillRange => monsterClass?.CurrentSkillRange ?? 0;

    [FoldoutGroup("Skill Stats"), ReadOnly]
    [ShowInInspector]
    public float CurrentSkillDuration => monsterClass?.CurrentSKillDuration ?? 0;

    [FoldoutGroup("Armor"), ReadOnly]
    [ShowInInspector]
    public float CurrentArmor => monsterClass?.CurrentArmor ?? 0;

    [FoldoutGroup("Status")]
    [ReadOnly]
    [ShowInInspector]
    public bool IsDead => isDie;

    [FoldoutGroup("Elite Stats"), ReadOnly]
    [ShowInInspector]
    public List<string> EliteAbilities
    {
        get
        {
            var abilities = new List<string>();
            if (monsterClass is EliteMonster eliteMonster)
            {
                foreach (var ability in eliteMonster.GetEliteAbilities())
                {
                    abilities.Add($"{ability.AbilityName} - {ability.Description}");
                }
            }
            return abilities;
        }
    }
    private void Awake()
    {
        uiManager = GetComponent<MonsterUIManager>(); // ���� �� �� ���� ��������
        simpleDissolveContorller = GetComponent<SimpleDissolveController>();
        skillSpawnPoint = GetComponentsInChildren<Transform>()
          .FirstOrDefault(t => t.name == "SkillSpawnPoint");

        if (skillSpawnPoint == null)
        {
            Debug.LogWarning($"{gameObject.name}���� SkillSpawnPoint�� ã�� ���߽��ϴ�. ���� ��ġ�� ����մϴ�.");
            skillSpawnPoint = transform;
           
        }
    }

    public virtual void Initialize(IMonsterClass monster)
    {
        monsterClass = monster;
        
        // AI Ÿ�Կ� ���� ������ AI ������Ʈ �߰�
        creatureAI = /*monster is BossMonster ?*/
            //gameObject.AddComponent<BossAI>() :
            gameObject.AddComponent<BasicCreatureAI>();
    }
    //public AttackType GetAttackType()
    //{
    //    //return monsterClass.IsBasicAttack() ? AttackType.Normal : AttackType.Charge;
    //}
   
    public virtual void TakeDamage(int damage)
    {
        if (isDie) return;

        // ���� ������ ����
        int originalDamage = damage;

        // TakeDamage ȣ��
        monsterClass.TakeDamage(damage);

        // ���� ����� ������ ��������
        int finalDamage = monsterClass.LastAppliedDamage;

        // UI ������Ʈ
        if (uiManager != null)
        {
            uiManager.UpdateHealthUI(monsterClass.CurrentHealth);
            uiManager.UpdateArmorUI(monsterClass.CurrentArmor);
            uiManager.SpawnDamageText(finalDamage); // ���� ����� ������
        }

        // ������ �ڵ�� �״��
        var CreatureAI = GetComponent<CreatureAI>();
        if (CreatureAI != null)
        {
            CreatureAI.OnDamaged(originalDamage); // AI���� ���� ������ ����
        }

        Rigidbody rb = GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }

        CameraShakeManager.TriggerShake(0.5f, 0.05f);

        if (monsterClass.CurrentHealth <= 0 && gameObject != null)
        {
            Die();
        }
    }
    public void TakeDotDamage(int dotDamage)
    {
        //if (!isDie)
        //{
        //    monsterClass.TakeDotDamage(dotDamage);

        //    if (monsterClass.CurrentHealth <= 0)
        //    {    
        //        Die();
        //    }
        //}

    }
    public Transform GetSkillSpawnPoint()
    {
        return skillSpawnPoint;
    }
    // ���� ���ؿ��� �ִϸ��̼� Ʈ���� ����
    public virtual void Die()
    {
        if (!isDie)
        {
           Debug.Log(monsterClass.MONSTERNAME);
            Debug.Log("�߾���");
            monsterClass.Die();
            isDie = true;
            // ���� Ÿ�Կ� ���� ���� ���൵ ����
            if (monsterClass is BossMonster)
            {
                AchievementManager.Instance.IncrementAchievement(1004); // ���� ���� ID
               
            }
            else if (monsterClass is EliteMonster)
            {
                AchievementManager.Instance.IncrementAchievement(1003); // ����Ʈ ���� ID
            }
            else
            {
                AchievementManager.Instance.IncrementAchievement(1001); // �Ϲ� ���� ���� ID
                AchievementManager.Instance.IncrementAchievement(1002); // �Ϲ� ���� ID
            }
            if (SaveManager.Instance != null)
            {
                var playerData = SaveManager.Instance.GetPlayerData();

                if (monsterClass is BossMonster)
                {
                    playerData.bossKillCount++; 
                }
                else if (monsterClass is EliteMonster)
                {
                    playerData.eliteMonsterKillCount++;
                }
                else
                {
                    playerData.normalMonsterKillCount++;
                }

                SaveManager.Instance.SavePlayerData();
            }
            Debug.Log(monsterClass.IsAlive);
            if (ItemDropSystem.Instance != null)
            {
                // ���� ������ Ȯ��
                ICreatureData monData = monsterClass.GetMonsterData();
                Debug.Log($"[Monster] Die - ���� ID: {monData.MonsterID}, ��� ������: {monData.dropItem}, ��� Ȯ��: {monData.dropChance}");

                // ��� ���̺� Ȯ��
                if (DropTableManager.Instance != null)
                {
                    var dropTable = DropTableManager.Instance.GetMonsterDropTable(monData.MonsterID);
                    Debug.Log($"[Monster] ��� ���̺� �˻� ���: {monsterClass.MONSTERNAME}{(dropTable != null ? dropTable.Count + "�� �׸�" : "����")}");
                }
                else
                {
                    Debug.LogError("[Monster] DropTableManager �ν��Ͻ��� null�Դϴ�!");
                }

                // ������ ��� ����
                ItemDropSystem.Instance.DropItemFromMonster(monData, transform.position);
                DungeonManager.Instance.OnMonsterDefeated(this);
            }
            if (simpleDissolveContorller != null)
            {
                simpleDissolveContorller.OnMonsterDeath();
            }
            /*Destroy(gameObject);*/ // ���� ������Ʈ ���� => �����꿡�� ����
        }

    }
    public IMonsterClass GetMonsterClass()
    {
        return monsterClass;
    }

    public void ModifyHealth(int modifier)
    {
        monsterClass.ModifyStats(healthAmount: modifier);
        if (uiManager != null)
        {
            uiManager.UpdateHealthUI(monsterClass.CurrentHealth);
        }
    }
    public void ModifyMaxHealth(int modifier)
    {
        monsterClass.ModifyStats(maxHealthAmount: modifier);
        if (uiManager != null)
        {
            uiManager.UpdateHealthUI(monsterClass.MaxHealth);
        }
    }
    public void ModifyDefense(int modifier)
    {
        monsterClass.ModifyStats(defenseAmount: modifier);
      
    }

    public void ModifyAttackPower(int modifier)
    {
        monsterClass.ModifyStats(attackAmount: modifier);
       
    }

    public void ModifyAttackSpeed(float modifier)
    {
        monsterClass.ModifyStats(attackSpeedAmount: modifier);
        // �ִϸ����Ͱ� �ִٸ� �ִϸ��̼� �ӵ��� ����
        //Animator animator = GetComponent<Animator>();
        //if (animator != null)
        //{
        //    animator.speed = monsterClass.CurrentAttackSpeed;
        //}
    }

    public void ModifySpeed(int modifier)
    {
        monsterClass.ModifyStats(speedAmount: modifier);
       
    }

    public void ModifySkillCooldown(float modifier)
    {
        monsterClass.ModifyStats(skillCooldownAmount: modifier);
    }

    public void ModifyAreaRadius(float modifier)
    {
        monsterClass.ModifyStats(areaRadiusAmount: modifier);
    }

    public void ModifyBuffValue(float modifier)
    {
        monsterClass.ModifyStats(buffValueAmount: modifier);
    }

    public void ModifySkillRange(float modifier)
    {
        monsterClass.ModifyStats(skillRangeAmount: modifier);
    }

    public void ModifyAttackRange(float modifier)
    {
        monsterClass.ModifyStats(attackRangeAmount: modifier);
    }
    public void ModifyArmor(int modifier)
    {
        monsterClass.ModifyStats(armorAmount: modifier);
        if (uiManager != null)
        {
            uiManager.UpdateArmorUI(monsterClass.CurrentArmor);
        }
    }

    // �Ͻ����� ����/����� ������ ���� �޼���
    public void ApplyTemporaryModifier(string statType, float modifier, float duration)
    {
        StartCoroutine(TemporaryModifierCoroutine(statType, modifier, duration));
    }

    private IEnumerator TemporaryModifierCoroutine(string statType, float modifier, float duration)
    {
        // ���� ����
        ApplyModifier(statType, modifier);

        // ������ �ð���ŭ ���
        yield return new WaitForSeconds(duration);

        // ���� ����
        ApplyModifier(statType, -modifier);
    }

    private void ApplyModifier(string statType, float modifier)
    {
        switch (statType.ToLower())
        {
            case "health":
                ModifyHealth((int)modifier);
                break;
            case "defense":
                ModifyDefense((int)modifier);
                break;
            case "attackpower":
                ModifyAttackPower((int)modifier);
                break;
            case "attackspeed":
                ModifyAttackSpeed(-modifier);
                break;
            case "speed":
                ModifySpeed((int)modifier);
                break;
            case "skillrange":
                ModifySkillRange(modifier);
                break;
            case "attackrange":
                ModifyAttackRange(modifier);
                break;
            default:
                Debug.LogWarning($"Unknown stat type: {statType}");
                break;
        }
    }

    // ���� ȿ�� ������ ���� ���� �޼���
    public void ApplyBuff(BuffType buffType, float value, float duration)
    {
        switch (buffType)
        {
            case BuffType.AttackUp:
                ApplyTemporaryModifier("attackpower", value, duration);
                break;
            case BuffType.DefenseUp:
                ApplyTemporaryModifier("defense", value, duration);
                break;
            case BuffType.SpeedUp:
                ApplyTemporaryModifier("speed", value, duration);
                break;
            case BuffType.AttackSpeedUp:
                ApplyTemporaryModifier("attackspeed", value, duration);
                break;
                // �ٸ� ���� Ÿ�Ե鿡 ���� ó�� �߰�
        }

        // ���� ����Ʈ ǥ��
        //if (uiManager != null)
        //{
        //    uiManager.ShowBuffEffect(buffType);
        //}
    }

    protected virtual void OnDestroy()
    {

    }

  

    IMonsterClass ICreatureStatus.GetMonsterClass()
    {
        return monsterClass;
    }

    public virtual DamageType GetDamageType()
    {
        Debug.Log("���͵�����Ÿ��ȣ��");
        return DamageType.Monster;
    }

    public Transform GetMonsterTransform()
    {
        Debug.Log("ȣ��!@!@!@");
        return gameObject.transform;
    }
}
