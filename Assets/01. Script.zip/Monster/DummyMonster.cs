using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DummyMonster : MonsterClass
{   
    
    public DummyMonster(ICreatureData data) : base(data)
    {
    }

    protected override void Debuff()
    {

    }
    public override void Attack()
    {
        
    }

  
    
  
}
