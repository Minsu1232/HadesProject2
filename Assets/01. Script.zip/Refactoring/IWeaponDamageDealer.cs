﻿using System;

internal interface IWeaponDamageDealer
{
  int GetDamage();

  
}